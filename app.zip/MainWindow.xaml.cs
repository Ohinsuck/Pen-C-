using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.Graphics.Canvas.UI.Xaml;
using Windows.UI;  // Use Windows.UI namespace for Color
using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI;
using System.Diagnostics;

namespace App8
{
    public sealed partial class MainWindow : Window
    {
        private bool flag = false;
        private float px = 100, py = 100, mySize = 16;
        private List<float> vx = new List<float>();
        private List<float> vy = new List<float>();
        private List<Color> col = new List<Color>();  // Use Windows.UI.Color here
        private List<float> size = new List<float>();
        private Color myCol = Colors.Green;  // Use Colors from Windows.UI

        public MainWindow()
        {
            this.InitializeComponent();
        }

        // Canvas Control - Draw
        private void CanvasControl_Draw(CanvasControl sender, CanvasDrawEventArgs args)
        {
            int n = vx.Count;
            if (n <= 2) return;

            for (int i = 1; i < n; i++)
            {
                if (vx[i] == 0.0f && vy[i] == 0.0f)
                {
                    i++;
                    continue;
                }
                args.DrawingSession.DrawLine(vx[i - 1], vy[i - 1], vx[i], vy[i], col[i], size[i]);
                args.DrawingSession.FillCircle(vx[i - 1], vy[i - 1], size[i] / 2, col[i]);
                args.DrawingSession.FillCircle(vx[i], vy[i], size[i] / 2, col[i]);
            }
        }

        // Canvas Pointer Pressed - Start Drawing
        private void CanvasControl_PointerPressed(object sender, PointerRoutedEventArgs e)
        {
            flag = true;
        }

        // Canvas Pointer Moved - Drawing Logic
        private void CanvasControl_PointerMoved(object sender, PointerRoutedEventArgs e)
        {
            var point = e.GetCurrentPoint(sender as CanvasControl).Position;
            px = (float)point.X;
            py = (float)point.Y;

            if (flag)
            {
                vx.Add(px);
                vy.Add(py);
                col.Add(myCol);
                size.Add(mySize);
                (sender as CanvasControl).Invalidate();
            }
        }

        // Canvas Pointer Released - Stop Drawing
        private void CanvasControl_PointerReleased(object sender, PointerRoutedEventArgs e)
        {
            flag = false;
            px = py = 0.0f;
            vx.Add(px);
            vy.Add(py);
            col.Add(myCol);
            size.Add(mySize);
        }

        // ColorPicker Changed - Update Color
        private void ColorPicker_ColorChanged(ColorPicker sender, ColorChangedEventArgs args)
        {
            myCol = args.NewColor;
        }

        // Slider Value Changed - Update Size
        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            mySize = (float)e.NewValue;
        }

        // Button Write Click - Save Data to File
        private async void myWrite_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Correct file path with a valid file name
                using (StreamWriter writer = new StreamWriter("C:\\Users\\user\\Desktop\\Savepoint\\myfile.txt"))
                {
                    int num = vx.Count;
                    writer.WriteLine(num);
                    for (int i = 0; i < num; i++)
                    {
                        writer.WriteLine($"{vx[i]} {vy[i]} {col[i].A} {col[i].B} {col[i].G} {col[i].R} {size[i]}");
                    }
                }
                ShowMessage("The file was written successfully.", "Success");
            }
            catch (Exception ex)
            {
                ShowMessage($"Error writing file: {ex.Message}", "Error");
            }
        }

        // Button Clear Click - Clear All Data
        private void myClear_Click(object sender, RoutedEventArgs e)
        {
            // Clear the data
            vx.Clear();
            vy.Clear();
            col.Clear();
            size.Clear();

            // Reset other states
            flag = false;
            px = 100;
            py = 100;
            mySize = 16;
        }





        // Menu - Clear All Data
        private void MenuFlyoutItem_Click(object sender, RoutedEventArgs e)
        {
            vx.Clear();
            vy.Clear();
            size.Clear();
            col.Clear();
        }

        // Menu - Save Data to File
        private void MenuFlyoutItem_Click_1(object sender, RoutedEventArgs e)
        {
            myWrite_Click(sender, e);
        }

       

        // Menu - Exit Application
        private void MenuFlyoutItem_Click_3(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Show MessageDialog
        private async void ShowMessage(string message, string title)
        {
            ContentDialog messageDialog = new ContentDialog()
            {
                Title = title,
                Content = message,
                CloseButtonText = "OK"
            };

            // XamlRoot ����
            messageDialog.XamlRoot = this.Content.XamlRoot;

            await messageDialog.ShowAsync();  // Dialog show
        }
    }
}
